﻿using System.Collections.Generic;

namespace UniversalLauncher.Models
{
    public class GameFolder
    {
        public string Name { get; set; } = "";
        public List<string> Games { get; set; } = new List<string>();
        public bool IsSystemFolder { get; set; }//Tells the app if this is a default, unremovable folder

        // COSTRUTTORE VUOTO OBBLIGATORIO PER IL JSON
        public GameFolder() { }
        public GameFolder(string name, bool isSystemFolder = false)
        {
            Name = name;
            IsSystemFolder = isSystemFolder;
        }
        public string BackgroundColor { get; set; } = "#28282D";
        public string IconSymbolName { get; set; } = "Folder24";
    }

}