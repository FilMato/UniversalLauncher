﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;
using UniversalLauncher.Models.GamesModels;

namespace UniversalLauncher.Services
{
    public class SteamGridService
    {
        // Questo è il nostro browser invisibile
        private readonly HttpClient _client;
        private const string ApiKey = "7dee33b3f949b5046dd7237a91a16663";// chiave di accesso al sito

        public SteamGridService()
        {
            _client = new HttpClient();
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", ApiKey);
            //Diciamo al server che siamo un browser amichevole
            _client.DefaultRequestHeaders.Add("User-Agent", "UniversalLauncher/1.0");
        }

        // Questo metodo usa "async" così il tuo launcher continua a scorrere fluido mentre lui scarica in background
        public async Task FetchImagesForGameAsync(Game game)
        {
            try
            {   
                if(string.IsNullOrEmpty(game.Title)) return; // Se il gioco non ha un titolo, non possiamo cercarlo!
                // PASSO 1: Cerchiamo l'ID del gioco partendo dal titolo formattato
                string searchUrl = $"https://www.steamgriddb.com/api/v2/search/autocomplete/{Uri.EscapeDataString(game.Title)}";
                var searchResponse = await _client.GetStringAsync(searchUrl);
                // Otteniamo la risposta JSON con i possibili giochi che corrispondono al titolo
                using var searchDoc = JsonDocument.Parse(searchResponse);
                var dataArray = searchDoc.RootElement.GetProperty("data");
                if (dataArray.GetArrayLength() == 0) return;// Se non lo trova, ci fermiamo qui
                string gameId = dataArray[0].GetProperty("id").GetInt32().ToString();// Prendiamo l'ID del primo risultato, che dovrebbe essere il più rilevante

                // PASSO 2: Ora che sappiamo l'ID cerchiamo la copertina di dimensioni 600x900 o 342x482
                string gridUrl = $"https://www.steamgriddb.com/api/v2/grids/game/{gameId}?dimensions=600x900,342x482";
                var gridResponse = await _client.GetStringAsync(gridUrl);
                using var gridDoc = JsonDocument.Parse(gridResponse);
                var gridData = gridDoc.RootElement.GetProperty("data");
                if (gridData.GetArrayLength() > 0)
                {
                    game.CoverImageUrl = gridData[0].GetProperty("url").GetString() ?? "";// Salviamo l'URL dell'immagine nel nostro gioco!
                }

                // PASSO 3: Cerchiamo l'Iconina 
                string iconUrl = $"https://www.steamgriddb.com/api/v2/icons/game/{gameId}";
                var iconResponse = await _client.GetStringAsync(iconUrl);
                using var iconDoc = JsonDocument.Parse(iconResponse);
                var iconData = iconDoc.RootElement.GetProperty("data");
                if (iconData.GetArrayLength() > 0)
                {
                    game.IconImageUrl = iconData[0].GetProperty("url").GetString() ?? ""; // Salviamo l'URL dell'icona
                }
            }
            catch (Exception ex)
            {
                // Stampiamo l'errore nella console di Visual Studio
                System.Diagnostics.Debug.WriteLine($"Errore API SteamGrid per {game.Title}: {ex.Message}");
            }
        }
    }
}